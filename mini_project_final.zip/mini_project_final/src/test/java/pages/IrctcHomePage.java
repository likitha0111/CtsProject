package pages;
 
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.time.LocalDate;
 
public class IrctcHomePage {
    WebDriver driver;
    JavascriptExecutor js;
 
    public IrctcHomePage(WebDriver driver) {
        this.driver = driver;
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }
 
    @FindBy(xpath = "//*[@id='origin']/span/input")
    WebElement fromStation;
 
    @FindBy(xpath = "//*[@id='destination']/span/input")
    WebElement toStation;
 
    @FindBy(id = "jDate")
    WebElement datePicker;
 
    @FindBy(xpath = "//*[@id='journeyClass']/div/div[2]/span")
    WebElement classDropdown;
 
    @FindBy(xpath = "//*[@id=\"journeyClass\"]/div/div[4]/div/ul/p-dropdownitem[12]/li")
    WebElement sleeperClass;
 
    @FindBy(id = "journeyQuota")
    WebElement quotaDropdown;
 
    @FindBy(xpath = "//*[@id=\"journeyQuota\"]/div/div[4]/div/ul/p-dropdownitem[4]/li/span")
    WebElement disabledQuota;
 
    @FindBy(xpath = "//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/p-confirmdialog/div/div/div[3]/button")
    WebElement quotaOkButton;
 
    @FindBy(xpath = "//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/div/form/div[4]/div/span[1]/label")
    WebElement disabilityCheckbox;
 
    @FindBy(xpath = "//*[@class='ui-button-text ui-clickable']")
    WebElement checkboxOkButton;
 
    public void enterFromStation(String station) throws InterruptedException {
        fromStation.sendKeys(station);
        Thread.sleep(1000);
        fromStation.sendKeys(Keys.ENTER);
    }
 
    public void enterToStation(String station) throws InterruptedException {
        toStation.sendKeys(station);
        Thread.sleep(1000);
        toStation.sendKeys(Keys.ENTER);
    }
 
    public void selectJourneyDate(int daysFromToday) throws InterruptedException {
        datePicker.click();
        Thread.sleep(1000);
        String day = String.valueOf(LocalDate.now().plusDays(daysFromToday).getDayOfMonth());
        driver.findElement(By.xpath("//a[text()='" + day + "']")).click();
    }
 
    public void selectSleeperClass() throws InterruptedException {
        classDropdown.click();
        Thread.sleep(1000);
        sleeperClass.click();
    }
 
    public void selectDisabilityQuota() throws InterruptedException {
        quotaDropdown.click();
        Thread.sleep(1000);
        disabledQuota.click();
        Thread.sleep(1000);
        quotaOkButton.click();
    }
 
    public void enableDisabilityCheckbox() throws InterruptedException {
    	WebElement pwdCheckbox = driver.findElement(By.xpath("/html/body/app-root/app-home/div[3]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/div/form/div[4]/div/span[1]/label"));
        if (!pwdCheckbox.isSelected()) {
        	Thread.sleep(1000);
            pwdCheckbox.click();
        }
    }
}