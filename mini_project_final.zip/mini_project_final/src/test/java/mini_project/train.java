package mini_project;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.TakesScreenshot;
import java.io.File;
import java.time.LocalDate;

public class train {
	static ChromeDriver driver;
	public static void main(String[] args) throws Exception {
    	driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.irctc.co.in/nget/train-search");
       
        //from destination
        WebElement fromdesti = driver.findElement(By.xpath("//*[@id=\"origin\"]/span/input"));
        fromdesti.sendKeys("HYB");
        Thread.sleep(1000);
        WebElement hyd= driver.findElement(By.xpath("//span[contains(text(),'HYDERABAD DECAN - HYB')]"));
        JavascriptExecutor js= (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();",hyd);
     
        //to destination
        WebElement todesti = driver.findElement(By.xpath("//*[@id=\"destination\"]/span/input"));
        todesti.sendKeys("PUNE");
        Thread.sleep(1000);
        todesti.sendKeys(Keys.ENTER);
      
        //date
        WebElement date= driver.findElement(By.xpath("//*[@id=\"jDate\"]"));
        date.click();
        Thread.sleep(1000);
        LocalDate futureDate = LocalDate.now().plusDays(4);
        String day = String.valueOf(futureDate.getDayOfMonth());
        driver.findElement(By.xpath("//a[text()='" + day + "']")).click();
        
        //class dropdown
        WebElement classtable = driver.findElement(By.xpath("//*[@id=\"journeyClass\"]/div/div[2]/span"));
        Thread.sleep(1000);
        classtable.click();
        WebElement sleeperOption = driver.findElement(By.xpath("//*[@id=\"journeyClass\"]/div/div[4]/div/ul/p-dropdownitem[12]/li"));
        Thread.sleep(1000);
        sleeperOption.click();

        // disability dropdown
        WebElement compdrop = driver.findElement(By.xpath("//*[@id=\"journeyQuota\"]/div"));
        Thread.sleep(1000);
        compdrop.click();
        WebElement disable = driver.findElement(By.xpath("//*[@id=\"journeyQuota\"]/div/div[4]/div/ul/p-dropdownitem[4]/li/span"));
        Thread.sleep(1000);
        disable.click();
        WebElement okdisablebutton= driver.findElement(By.xpath("//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/p-confirmdialog/div/div/div[3]/button/span[2]"));
        Thread.sleep(1000);
        okdisablebutton.click();
        
        //disability box
        WebElement disableCheckbox = driver.findElement(By.xpath("//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/div/form/div[4]/div/span[1]/label"));
        Thread.sleep(1000);
        disableCheckbox.click();
        WebElement okbutton= driver.findElement(By.xpath("//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/p-confirmdialog/div/div/div[3]/button/span[2]"));
        Thread.sleep(1000);
        okbutton.click();
        
       //search button
        WebElement search = driver.findElement(By.xpath("//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/div/form/div[5]/div[1]/button"));
        Thread.sleep(1000);
        search.click();
        
        //Screenshot     
        TakesScreenshot sc=(TakesScreenshot) driver;
        File screenshot= sc.getScreenshotAs(OutputType.FILE);    
        FileUtils.copyFile(screenshot, new File("C:\\Users\\2403449\\eclipse-workspace\\mini_project_final\\screenshot1\\pict1.png"));
        driver.close();
    }
}
