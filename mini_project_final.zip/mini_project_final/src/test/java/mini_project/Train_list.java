package mini_project;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.time.LocalDate;
//import java.util.List;
import java.util.Set;

public class Train_list {
	static ChromeDriver driver;
	public static void main(String[] args) throws Exception {
    	driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.irctc.co.in/nget/train-search");
       
        //from destination
        WebElement fromdesti = driver.findElement(By.xpath("//*[@id=\"origin\"]/span/input"));
        fromdesti.clear();
        fromdesti.sendKeys("hyb");
        Thread.sleep(1000);
        WebElement hyd= driver.findElement(By.xpath("//span[contains(text(),'HYDERABAD DECAN - HYB')]"));
        JavascriptExecutor js= (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();",hyd);
     
        //to destination
        WebElement todesti = driver.findElement(By.xpath("//*[@id=\"destination\"]/span/input"));
        todesti.sendKeys("pune");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"p-highlighted-option\"]")).click();
      
        //date
        driver.findElement(By.xpath("//*[@id=\"jDate\"]")).click();
        Thread.sleep(1000);
        LocalDate futureDate = LocalDate.now().plusDays(4);
        String day = String.valueOf(futureDate.getDayOfMonth());
        driver.findElement(By.xpath("//a[text()='" + day + "']")).click();
        
        //class dropdown
        WebElement classtable = driver.findElement(By.xpath("//*[@id=\"journeyClass\"]/div/div[2]/span"));
        Thread.sleep(1000);
        classtable.click();
        WebElement sleeperOption = driver.findElement(By.xpath("//*[@id=\"journeyClass\"]/div/div[4]/div/ul/p-dropdownitem[12]/li"));
        Thread.sleep(1000);
        sleeperOption.click();

        // disability dropdown
        WebElement compdrop = driver.findElement(By.xpath("//*[@id=\"journeyQuota\"]/div"));
        Thread.sleep(1000);
        compdrop.click();
        WebElement disable = driver.findElement(By.xpath("//*[@id=\"journeyQuota\"]/div/div[4]/div/ul/p-dropdownitem[4]/li/span"));
        Thread.sleep(1000);
        disable.click();
        WebElement okdisablebutton= driver.findElement(By.xpath("//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/p-confirmdialog/div/div/div[3]/button/span[2]"));
        Thread.sleep(1000);
        okdisablebutton.click();
        
        //disability box
        WebElement disableCheckbox = driver.findElement(By.xpath("//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/div/form/div[4]/div/span[1]/label"));
        Thread.sleep(1000);
        JavascriptExecutor js1= (JavascriptExecutor) driver;
        js1.executeScript("arguments[0].click();", disableCheckbox);
        WebElement okbutton= driver.findElement(By.xpath("//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/p-confirmdialog/div/div/div[3]/button/span[2]"));
        Thread.sleep(1000);
        okbutton.click();
                
       //search button
        WebElement search = driver.findElement(By.xpath("//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/div/form/div[5]/div[2]/button"));
        Thread.sleep(1000);
        search.click();

    
        TakesScreenshot sc=(TakesScreenshot) driver;
        File screenshot= sc.getScreenshotAs(OutputType.FILE);    
        FileUtils.copyFile(screenshot, new File("C:\\Users\\2403449\\eclipse-workspace\\mini_project_1\\screenshot1\\pict1.png"));
        
        String originalWindow=driver.getWindowHandle();
        Set<String> allWindows=driver.getWindowHandles();
        for(String window:allWindows)
        {
        	if(!window.equals(originalWindow))
        	{
        		driver.switchTo().window(window);
        		break;
        	}
        }
        Thread.sleep(1000);
       /* java.util.List<WebElement> trains = driver.findElements(By.xpath("//*[@id=\"corover-body\"]/div/div[2]/div[1]"));
        for (WebElement train : trains) {
            System.out.println("Number of trains: " + train.getText());
        }
        
        List<WebElement> trainname=driver.findElements(By.xpath("//div[@class='sc-bhqpjJ kmzMGj']//div//p[contains(@style, 'margin-top: 6px')]"));
        for(WebElement t:trainname) {
       	 System.out.println(t.getText());
        }*/
            
        TakesScreenshot sc1=(TakesScreenshot) driver;
        File screenshot1= sc1.getScreenshotAs(OutputType.FILE);    
        FileUtils.copyFile(screenshot1, new File("C:\\Users\\2403449\\eclipse-workspace\\mini_project_final\\screenshot1\\pict2.png"));
        driver.close();
    }
	}
