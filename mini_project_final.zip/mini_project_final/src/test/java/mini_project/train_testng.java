package mini_project;

import org.testng.annotations.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.time.LocalDate;

public class train_testng {
    WebDriver driver;
    JavascriptExecutor js;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        js = (JavascriptExecutor) driver;
        driver.manage().window().maximize();
    }

    @Test(priority = 1)
    public void launchIRCTC() {
        driver.get("https://www.irctc.co.in/nget/train-search");
    }

    
    @Test(priority = 2)
    public void verifyPageTitle() {
        String expectedTitle = "IRCTC Next Generation eTicketing System";
        assert driver.getTitle().contains(expectedTitle);
    }

    @Test(priority = 3)
    public void enterFromStation() throws InterruptedException {
        WebElement from = driver.findElement(By.xpath("//*[@id='origin']/span/input"));
        from.sendKeys("HYB");
        Thread.sleep(1000);
        from.sendKeys(Keys.ENTER);
    }

    @Test(priority = 4)
    public void enterToStation() throws InterruptedException {
        WebElement to = driver.findElement(By.xpath("//*[@id='destination']/span/input"));
        to.sendKeys("PUNE");
        Thread.sleep(1000);
        to.sendKeys(Keys.ENTER);
    }

    @Test(priority = 5)
    public void selectJourneyDate() throws InterruptedException {
        driver.findElement(By.id("jDate")).click();
        Thread.sleep(1000);
        LocalDate futureDate = LocalDate.now().plusDays(4);
        String day = String.valueOf(futureDate.getDayOfMonth());
        driver.findElement(By.xpath("//a[text()='" + day + "']")).click();
    }
    @Test(priority = 6)
    public void selectSleeperClass() throws InterruptedException {
        WebElement classDropdown = driver.findElement(By.xpath("//*[@id='journeyClass']/div/div[2]/span"));
        classDropdown.click();
        Thread.sleep(1000);
        WebElement sleeper = driver.findElement(By.xpath("//*[@id=\"journeyClass\"]/div/div[4]/div/ul/p-dropdownitem[12]/li"));
        sleeper.click();
    }

    @Test(priority = 7)
    public void selectDisabilityQuota() throws InterruptedException {
        WebElement quotaDropdown = driver.findElement(By.id("journeyQuota"));
        quotaDropdown.click();
        Thread.sleep(1000);
        WebElement disabledQuota = driver.findElement(By.xpath("//*[@id=\"journeyQuota\"]/div/div[4]/div/ul/p-dropdownitem[4]/li/span"));
        disabledQuota.click();
        Thread.sleep(1000);
        WebElement okButton = driver.findElement(By.xpath("//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/p-confirmdialog/div/div/div[3]/button"));
        okButton.click();
    }

    @Test(priority = 9)
    public void enableDisabilityCheckbox() throws InterruptedException {
        WebElement checkbox = driver.findElement(By.xpath("//*[@id=\"divMain\"]/div/app-main-page/div/div/div[1]/div[1]/div[1]/app-jp-input/div/form/div[4]/div/span[1]/label"));
        js.executeScript("arguments[0].click();", checkbox);
        Thread.sleep(1000);
        WebElement okButton = driver.findElement(By.xpath("//*[@class='ui-button-text ui-clickable']"));
        okButton.click();
    }

    @Test(priority = 8)
    public void captureScreenshot() throws Exception {
        TakesScreenshot sc = (TakesScreenshot) driver;
        File screenshot = sc.getScreenshotAs(OutputType.FILE);
        Thread.sleep(1000);
        FileUtils.copyFile(screenshot, new File("screenshot1/pictu1.png"));
    }
 
    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
