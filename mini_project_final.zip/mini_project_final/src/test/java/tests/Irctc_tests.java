package tests;

import pages.IrctcHomePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import utility.ScreenshotUtil;

public class Irctc_tests {
    WebDriver driver;
    IrctcHomePage homePage;
 
    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        homePage = new IrctcHomePage(driver);
    }
 
    @Test(priority = 1)
    public void launchIRCTC() {
        driver.get("https://www.irctc.co.in/nget/train-search");
    }
 
    @Test(priority = 2)
    public void verifyPageTitle() {
        String expectedTitle = "IRCTC Next Generation eTicketing System";
        assert driver.getTitle().contains(expectedTitle);
    }
 
    @Test(priority = 3)
    public void enterFromStation() throws InterruptedException {
        homePage.enterFromStation("hyb");
    }
 
    @Test(priority = 4)
    public void enterToStation() throws InterruptedException {
        homePage.enterToStation("PUNE");
    }
 
    @Test(priority = 5)
    public void selectJourneyDate() throws InterruptedException {
        homePage.selectJourneyDate(4);
    }
 
    @Test(priority = 6)
    public void selectSleeperClass() throws InterruptedException {
        homePage.selectSleeperClass();
    }
 
    @Test(priority = 7)
    public void selectDisabilityQuota() throws InterruptedException {
        homePage.selectDisabilityQuota();
    }
 
    @Test(priority = 8)
    public void enableDisabilityCheckbox() throws InterruptedException {
        homePage.enableDisabilityCheckbox();
    }
 
    @Test(priority = 9)
    public void captureScreenshot() throws Exception {
        ScreenshotUtil.capture(driver, "screenshot1/pictu.png");
    }
 
    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}