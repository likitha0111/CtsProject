package utility;
 
import org.openqa.selenium.*;
import org.apache.commons.io.FileUtils;
 
import java.io.File;
 
public class ScreenshotUtil {
    public static void capture(WebDriver driver, String filePath) throws Exception {
        TakesScreenshot sc = (TakesScreenshot) driver;
        File screenshot = sc.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshot, new File(filePath));
    }
}